/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { TaskItem, WeeklyGoal, JournalEntry, FitnessLog, SocialHangout, AppReminder, SideQuest } from './types';

export const DAYS_OF_WEEK = [
  { short: 'Sun', name: 'Sunday', index: 0 },
  { short: 'Mon', name: 'Monday', index: 1 },
  { short: 'Tue', name: 'Tuesday', index: 2 },
  { short: 'Wed', name: 'Wednesday', index: 3 },
  { short: 'Thu', name: 'Thursday', index: 4 },
  { short: 'Fri', name: 'Friday', index: 5 },
  { short: 'Sat', name: 'Saturday', index: 6 },
];

export const EMOTE_OPTIONS = ['🌸', '🍃', '☀️', '☁️', '🎈', '⭐', '🌈', '🚲', '🍵', '📚', '🌱', '🧸', '🍊', '🌊', '🏡', '🎐'];

// Default Unlocked Emojis (users can unlock new emojis every 10 successful days or milestones)
export const DEFAULT_EMOJIS = ['🌸', '🍃', '☀️', '☁️', '🍵', '🌱', '🧸', '🍊'];
export const SPECIAL_EMOJIS = ['🎈', '⭐', '🌈', '🚲', '📚', '🌊', '🏡', '🎐', '🌻', '🐾', '🍰', '🎸', '🎨', '✨', '🧘', '🛸'];

export function getTodayDateStr(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getPastDateStr(offsetDays: number): string {
  const d = new Date();
  d.setDate(d.getDate() - offsetDays);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// Seed data
export const INITIAL_TASKS: TaskItem[] = [];

export const INITIAL_WEEKLY_GOALS: WeeklyGoal[] = [];

// Historical entry logs (to show green ticks on the Calendar for completed days)
export const INITIAL_JOURNAL_ENTRIES: Record<string, JournalEntry> = {};

export const INITIAL_FITNESS: Record<string, FitnessLog> = {};

export const INITIAL_SOCIALS: SocialHangout[] = [];

export const INITIAL_REMINDERS: AppReminder[] = [];

export const INITIAL_SIDE_QUESTS: SideQuest[] = [];
